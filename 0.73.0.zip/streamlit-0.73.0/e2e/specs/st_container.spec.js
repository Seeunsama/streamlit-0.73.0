/**
 * @license
 * Copyright 2018-2020 Streamlit Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

describe("st.container", () => {
  before(() => {
    cy.visit("http://localhost:3000/");
  });

  it("permits multiple out-of-order elements", () => {
    cy.get(".stMarkdown p")
      .eq(0)
      .contains("Line 2");
    cy.get(".stMarkdown p")
      .eq(1)
      .contains("Line 3");
    cy.get(".stMarkdown p")
      .eq(2)
      .contains("Line 1");
    cy.get(".stMarkdown p")
      .eq(3)
      .contains("Line 4");
  });

  it("persists widget state across reruns", () => {
    cy.get(".stCheckbox").click({ multiple: true });
    cy.get("h1").contains("Checked!");

    cy.get(".stButton button").click();
    cy.get("h2").contains("Pressed!");
    cy.get(".stCheckbox input").should("have.attr", "aria-checked", "true");
  });
});
