# SF bike statistics

## Data source

https://github.com/uber-common/deck.gl-data/blob/master/website/sf-bike-parking.json

## Changes

* Replaced `coordinates` with `lat`, `lon`.
