# BART statistics

## Data source

https://github.com/uber-common/deck.gl-data/blob/master/website/bart-stations.json

## Changes

* Replaced `coordinates` blocks with `lat`, `lon`.

