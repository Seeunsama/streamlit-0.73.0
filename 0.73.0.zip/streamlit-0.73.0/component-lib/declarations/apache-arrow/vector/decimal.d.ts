import { Decimal } from "../type";
import { BaseVector } from "./base";
/** @ignore */
export declare class DecimalVector extends BaseVector<Decimal> {}
