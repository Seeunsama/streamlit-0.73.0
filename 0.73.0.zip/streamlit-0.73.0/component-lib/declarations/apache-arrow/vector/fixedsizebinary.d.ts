import { BaseVector } from "./base";
import { FixedSizeBinary } from "../type";
/** @ignore */
export declare class FixedSizeBinaryVector extends BaseVector<
  FixedSizeBinary
> {}
