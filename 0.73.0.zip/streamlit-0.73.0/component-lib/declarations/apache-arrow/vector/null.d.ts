import { Null } from "../type";
import { BaseVector } from "./base";
/** @ignore */
export declare class NullVector extends BaseVector<Null> {}
