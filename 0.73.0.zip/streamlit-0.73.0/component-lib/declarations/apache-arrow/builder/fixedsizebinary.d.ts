import { FixedSizeBinary } from "../type";
import { FixedWidthBuilder } from "../builder";
/** @ignore */
export declare class FixedSizeBinaryBuilder<
  TNull = any
> extends FixedWidthBuilder<FixedSizeBinary, TNull> {}
