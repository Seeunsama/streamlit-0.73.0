/** @ignore */
export declare function valueToString(x: any): any;
