---
name: Documentation improvement request
about: Let us know how our docs could be better
title: ""
labels: docs, needs triage
assignees: ""
---

**Link to doc page in question (if any):**

**Name of the Streamlit feature whose docs need improvement:**

**What you think the docs should say:**
